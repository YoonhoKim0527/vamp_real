public class PhysicsConstants
{
    public static float g { get; } = 9.8f;
}