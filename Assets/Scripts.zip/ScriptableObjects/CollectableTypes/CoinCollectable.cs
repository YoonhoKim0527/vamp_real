using UnityEngine;

namespace Vampire
{
    [CreateAssetMenu(fileName = "Coin", menuName = "CollectableTypes/Coin", order = 1)]
    public class CoinCollectable : CollectableType {}
}
