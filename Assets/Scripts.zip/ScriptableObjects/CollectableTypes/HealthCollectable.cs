using UnityEngine;

namespace Vampire
{
    [CreateAssetMenu(fileName = "Health", menuName = "CollectableTypes/Health", order = 1)]
    public class HealthCollectable : CollectableType {}
}
