using UnityEngine;

namespace Vampire
{
    public class MainCharacter : Character
    {
        
    }
}
