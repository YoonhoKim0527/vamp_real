using System.Collections;
using UnityEngine;

namespace Vampire
{
    public class SwarmSpawner : MonoBehaviour
    {
        private EntityManager entityManager;
        private Character playerCharacter;

        private int swarmMonsterPoolIndex;          // ✅ 풀 인덱스 추가
        private MonsterBlueprint swarmMonsterBlueprint; // ✅ 몬스터 블루프린트 추가

        private float spawnInterval = 10f; // 몇 초마다 스폰
        private int swarmCount = 20;       // 한 번에 생성될 개수
        private float spawnRadius = 8f;    // 플레이어 기준 생성 반경
        private float swarmMoveSpeed = 6f; // 직진 속도
        private GameObject swarmMonsterPrefab;

        private float timer = 0f;

        public void Init(EntityManager manager, Character player, GameObject prefab, int poolIndex, MonsterBlueprint blueprint)
        {
            entityManager = manager;
            playerCharacter = player;
            swarmMonsterPrefab = prefab;
            swarmMonsterPoolIndex = poolIndex;
            swarmMonsterBlueprint = blueprint;
        }

        public void Tick()
        {
            timer += Time.deltaTime;
            if (timer >= spawnInterval)
            {
                timer = 0f;
                SpawnSwarm();
            }
        }

        private void SpawnSwarm()
        {
            Debug.Log("[SwarmSpawner] 🦇 박쥐 떼 스폰!");

            Vector2 playerPos = playerCharacter.transform.position;
            Vector2 spawnCenter = playerPos + Random.insideUnitCircle.normalized * spawnRadius;

            for (int i = 0; i < swarmCount; i++)
            {
                Vector2 spawnPos = spawnCenter + Random.insideUnitCircle * 1.5f; // 군집 생성
                Vector2 moveDir = (playerPos - spawnPos).normalized;

                SwarmMonster monster = entityManager.SpawnMonster(
                    swarmMonsterPoolIndex,
                    spawnPos,
                    swarmMonsterBlueprint
                ) as SwarmMonster;

                if (monster != null)
                {
                    monster.InitSwarm(spawnPos, moveDir, swarmMoveSpeed);
                }
            }
        }
    }
}
