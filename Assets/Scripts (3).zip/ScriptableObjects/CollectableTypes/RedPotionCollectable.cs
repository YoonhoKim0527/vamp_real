using UnityEngine;

namespace Vampire
{
    [CreateAssetMenu(fileName = "Red Potion", menuName = "CollectableTypes/Red Potion", order = 1)]
    public class RedPotionCollectable : CollectableType {}
}
