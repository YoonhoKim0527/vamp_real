using UnityEngine;

namespace Vampire
{
    [CreateAssetMenu(fileName = "Bomb", menuName = "CollectableTypes/Bomb", order = 1)]
    public class BombCollectable : CollectableType {}
}
