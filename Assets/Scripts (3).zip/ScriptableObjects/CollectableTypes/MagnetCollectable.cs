using UnityEngine;

namespace Vampire
{
    [CreateAssetMenu(fileName = "Magnet", menuName = "CollectableTypes/Magnet", order = 1)]
    public class MagnetCollectable : CollectableType {}
}
